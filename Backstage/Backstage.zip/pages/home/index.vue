<script setup></script>

<template>
  <p class="text-[32px]">HouseFun Index</p>
</template>

<style></style>
