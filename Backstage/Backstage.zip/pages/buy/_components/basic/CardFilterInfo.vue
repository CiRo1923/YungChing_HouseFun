<script setup>
import CardFilter from '@components/buy/mCard/Filter.vue'
import FormLabel from '@components/buy/mForm/Label.vue'

import CasePurpose from '@pages/buy/_components/basic/Info/CasePurpose.vue'
import CaseTitle from '@pages/buy/_components/basic/Info/CaseTitle.vue'
import Address from '@pages/buy/_components/basic/Info/Address.vue'
import CaseType from '@pages/buy/_components/basic/Info/CaseType.vue'
import CaseUsage from '@pages/buy/_components/basic/Info/CaseUsage.vue'
import Zoing from '@pages/buy/_components/basic/Info/Zoing.vue'
import CaseLandNo from '@pages/buy/_components/basic/Info/CaseLandNo.vue'

import { useBuyProjectStore } from '@stores/buy/project.js'

const buyProject = useBuyProjectStore()
const { options, apiData } = storeToRefs(buyProject)

const items = readonly([
  {
    id: 'casePurpose',
    label: '現況',
    class: ' p:h-[35px]',
  },
  {
    id: 'caseTitle',
    label: '物件標題',
    class: ' p:h-[40px]',
  },
  {
    id: 'address',
    label: '地址',
    class: ' p:h-[40px]',
  },
  {
    id: 'caseType',
    label: '型態',
    class: ' p:h-[40px]',
  },
  {
    id: 'caseUsage',
    label: '法定用途',
    class: ' p:h-[40px]',
  },
  {
    id: 'caseZoing',
    label: '土地分區',
    class: ' p:h-[35px]',
  },
  {
    id: 'caseLandNo',
    label: '地號',
    class: ' p:h-[40px]',
  },
])
</script>

<template>
  <CardFilter title="基本資料">
    <!-- <pre>{{ apiData }}</pre> -->
    <!-- <pre>{{ options.city }}</pre> -->
    <ul class="tm:space-y-[40px] p:space-y-[24px]">
      <li
        class="tm:space-y-[12px] p:flex p:gap-x-[8px]"
        v-for="(item, index) in items"
        :key="`${item.id}_${index}`"
      >
        <FormLabel
          :label="item.label"
          :setClass="{
            main: ['shrink-0 p:flex p:w-[100px] p:items-center', item.class],
          }"
        />
        <CasePurpose v-if="item.id === 'casePurpose'" />
        <CaseTitle v-if="item.id === 'caseTitle'" />
        <Address v-if="item.id === 'address'" />
        <CaseType v-if="item.id === 'caseType'" />
        <CaseUsage v-if="item.id === 'caseUsage'" />
        <Zoing v-if="item.id === 'caseZoing'" />
        <CaseLandNo v-if="item.id === 'caseLandNo'" />
      </li>
      <li class="p:flex">
        <FormLabel
          label="出售樓層"
          :setClass="{
            main: 'shrink-0 p:w-[100px]',
          }"
        />
      </li>
      <li class="p:flex">
        <FormLabel
          label="總樓高"
          :setClass="{
            main: 'shrink-0 p:w-[100px]',
          }"
        />
      </li>
      <li class="p:flex">
        <FormLabel
          label="屋齡"
          :setClass="{
            main: 'shrink-0 p:w-[100px]',
          }"
        />
      </li>
      <li class="p:flex">
        <FormLabel
          label="社區"
          :setClass="{
            main: 'shrink-0 p:w-[100px]',
          }"
        />
      </li>
      <li class="p:flex">
        <FormLabel
          label="格局"
          :setClass="{
            main: 'shrink-0 p:w-[100px]',
          }"
        />
      </li>
      <li class="p:flex">
        <FormLabel
          label="加蓋格局"
          :setClass="{
            main: 'shrink-0 p:w-[100px]',
          }"
        />
      </li>
      <li class="p:flex">
        <FormLabel
          label="電梯"
          :setClass="{
            main: 'shrink-0 p:w-[100px]',
          }"
        />
      </li>
      <li class="p:flex">
        <FormLabel
          label="朝向"
          :setClass="{
            main: 'shrink-0 p:w-[100px]',
          }"
        />
      </li>
      <li class="p:flex">
        <FormLabel
          label="建物結構"
          :setClass="{
            main: 'shrink-0 p:w-[100px]',
          }"
        />
      </li>
      <li class="p:flex">
        <FormLabel
          label="無障礙設施"
          :setClass="{
            main: 'shrink-0 p:w-[100px]',
          }"
        />
      </li>
    </ul>
  </CardFilter>
</template>

<style></style>
