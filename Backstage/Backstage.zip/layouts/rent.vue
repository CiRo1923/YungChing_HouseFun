<script setup></script>

<template>
  <div class="l-wrap">
    <main class="l-body">
      RENT
      <slot />
    </main>
  </div>
</template>

<style></style>
