import { defineStore } from 'pinia'

export const popupStore = defineStore('popup', () => {
})