// import { apiGETEealEstatePurposeCheckOptions } from '@js/buy/_api/index.js'
import { defineStore } from 'pinia'

export const useBuyBasicStore = defineStore('buyBasic', () => {})
