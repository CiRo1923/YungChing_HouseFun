export const dropShadow = {
  text: '0 8px 3px #0000008c'
}

export const letterSpacing = {
  default: '0.1em'
}

export const lineHeight = {
  '1em': '1em'
}
